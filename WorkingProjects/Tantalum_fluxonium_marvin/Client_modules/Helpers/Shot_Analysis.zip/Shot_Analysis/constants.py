import scipy.constants as ct

hbar = ct.hbar
kb = ct.k
echarge = ct.e
phi0 = ct.h / (2 * echarge)